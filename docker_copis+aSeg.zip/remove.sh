docker compose -p web-lab down --rmi all
