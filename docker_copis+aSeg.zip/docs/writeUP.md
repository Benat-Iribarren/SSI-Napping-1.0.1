# Write Up

## Componentes del grupo

Nombre.1 Apellido1.1 Apellido2.1
Nombre.2 Apellido1.2 Apellido2.2

## Guia de solución de la máquina

bla, bla, bla...
